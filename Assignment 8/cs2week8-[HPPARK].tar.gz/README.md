Caltech CS2 Assignment 8: Numerics

See [assignment8.html](http://htmlpreview.github.io/?https://github.com/caltechcs2/numerics/blob/master/assignment8.html)
