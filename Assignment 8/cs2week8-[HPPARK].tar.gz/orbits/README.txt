Forward Euler:
The planet's orbit gradually increases in size and moves further away from the
sun. The energy value (on average) gradually increases.

Symplectic Euler:
The planet's orbit remains stable. The energy value, like the orbit, remains
stable.

Backwards Euler:
The planet's orbit gradually shrinks and eventually intersects with the sun.
The energy value continues to decrease.