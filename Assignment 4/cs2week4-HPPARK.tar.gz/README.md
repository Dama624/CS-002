Caltech CS2 Assignment 4: Dynamic Programming

See [assignment4.html](http://htmlpreview.github.io/?https://github.com/caltechcs2/dna_carving/blob/master/assignment4.html)
